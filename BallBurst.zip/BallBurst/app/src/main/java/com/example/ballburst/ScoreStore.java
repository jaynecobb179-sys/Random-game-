package com.example.ballburst;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

/** Хранит топ-10 результатов в SharedPreferences (локально, без интернета). */
final class ScoreStore {

    static final class Entry {
        final long runId;
        final int score;
        final long time;

        Entry(long runId, int score, long time) {
            this.runId = runId;
            this.score = score;
            this.time = time;
        }
    }

    private static final String KEY = "top10";
    private final SharedPreferences sp;

    ScoreStore(Context ctx) {
        sp = ctx.getSharedPreferences("ballburst", Context.MODE_PRIVATE);
    }

    List<Entry> load() {
        ArrayList<Entry> list = new ArrayList<>();
        String s = sp.getString(KEY, "");
        if (s == null || s.isEmpty()) return list;
        for (String part : s.split(";")) {
            String[] f = part.split(":");
            if (f.length != 3) continue;
            try {
                list.add(new Entry(Long.parseLong(f[0]), Integer.parseInt(f[1]), Long.parseLong(f[2])));
            } catch (NumberFormatException ignored) {
            }
        }
        return list;
    }

    int best() {
        List<Entry> l = load();
        return l.isEmpty() ? 0 : l.get(0).score;
    }

    /** Добавляет или обновляет результат текущей партии (runId), оставляет 10 лучших. */
    void commit(long runId, int score) {
        if (score <= 0) return;
        List<Entry> list = load();
        long time = System.currentTimeMillis();
        Iterator<Entry> it = list.iterator();
        while (it.hasNext()) {
            Entry e = it.next();
            if (e.runId == runId) {
                time = e.time;
                it.remove();
            }
        }
        list.add(new Entry(runId, score, time));
        Collections.sort(list, (a, b) -> a.score != b.score
                ? Integer.compare(b.score, a.score)
                : Long.compare(a.time, b.time));
        while (list.size() > 10) list.remove(list.size() - 1);
        StringBuilder sb = new StringBuilder();
        for (Entry e : list) {
            if (sb.length() > 0) sb.append(';');
            sb.append(e.runId).append(':').append(e.score).append(':').append(e.time);
        }
        sp.edit().putString(KEY, sb.toString()).apply();
    }

    /** Место партии в топ-10 (1..10) или -1, если не попала. */
    int rankOf(long runId) {
        List<Entry> l = load();
        for (int i = 0; i < l.size(); i++) if (l.get(i).runId == runId) return i + 1;
        return -1;
    }
}
