package com.example.ballburst;

import android.app.Activity;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.DashPathEffect;
import android.graphics.Insets;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.SweepGradient;
import android.graphics.Typeface;
import android.os.Build;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowInsets;

import java.text.SimpleDateFormat;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Random;

/**
 * Ball Burst: вся игра (логика, отрисовка, меню) в одном View на Canvas.
 * Без внешних библиотек и без интернета.
 */
public class GameView extends View {

    // ---------- Настройки, которые удобно менять ----------
    static final int COLS = 10;              // шаров в ряду
    static final int START_ROWS = 6;         // стартовых рядов
    static final float FIRE_RADIUS = 3f;     // радиус огненного шара (в диаметрах шара)
    static final float BOOST_CHANCE = 0.12f; // шанс буста при каждой подзарядке (после паузы SINCE_BOOST_MIN)
    static final int SINCE_BOOST_MIN = 5;    // минимум обычных выстрелов между бустами
    static final float SHOT_SPEED_H = 1.5f;  // скорость выстрела (в высотах экрана за секунду)

    // ---------- Константы ----------
    static final int S_MENU = 0, S_PLAY = 1, S_PAUSE = 2, S_OVER = 3, S_SCORES = 4;
    static final int P_AIM = 0, P_FLY = 1, P_DESC = 2;
    static final int NCOL = 5, T_RAINBOW = 5, T_FIRE = 6, T_ELEC = 7;
    static final int[] COLORS = {0xFFFF4D5E, 0xFF3DDC84, 0xFF3AA0FF, 0xFFFFD23F, 0xFFB45CFF};
    static final int FX_POP = 0, FX_PART = 1, FX_FALL = 2, FX_RING = 3, FX_BOLT = 4, FX_TEXT = 5;
    static final int B_PLAY = 1, B_SCORES = 2, B_EXIT = 3, B_AGAIN = 4, B_MENU = 5, B_BACK = 6, B_RESUME = 7;

    static final class Row {
        final int[] t = new int[COLS];
        final float[] pulse = new float[COLS];

        Row() {
            Arrays.fill(t, -1);
        }
    }

    static final class Fx {
        int kind;
        float x, y, vx, vy, t, life, delay, size;
        int color;
        String text;
        float[][] lines;
    }

    static final class Btn {
        final RectF r = new RectF();
        String label;
        int id;
        boolean down;
    }

    private final Random rnd = new Random();
    private final ScoreStore store;
    private final ArrayList<Row> rows = new ArrayList<>();
    private final ArrayList<Fx> fx = new ArrayList<>();
    private int parity;

    // геометрия
    private int W, H;
    private float insetL, insetT, insetR, insetB, dp;
    private float fieldLeft, fieldW, d, r, rowH, gridTop, shooterX, shooterY;
    private int maxRows = 14;
    private float pauseCx, pauseCy, pauseR;

    // состояние
    private int state = S_MENU, phase = P_AIM;
    private int score, bestScore, rank, shots;
    private long runId, highlightRun = -1;
    private int curType, nextType, sinceBoost;
    private float time, descAnim, reloadT = 1f, shake, flash, overT;
    private int flashColor = 0xFFFFFFFF;

    // выстрел
    private float shotX, shotY, shotDX, shotDY;
    private int shotType;
    private final float[] trailX = new float[7], trailY = new float[7];
    private int trailN;

    // прицел
    private boolean aiming, aimValid, ghostOn, pauseDown, swapDown;
    private float aimX, aimY, aimAng = (float) (Math.PI / 2), ghostX, ghostY;
    private final float[] aimPts = new float[2 * 260];
    private int aimN;

    // цикл
    private boolean running;
    private long lastNs;

    // кнопки
    private final ArrayList<Btn> menuBtns = new ArrayList<>();
    private final ArrayList<Btn> overBtns = new ArrayList<>();
    private final ArrayList<Btn> scoreBtns = new ArrayList<>();
    private final ArrayList<Btn> pauseBtns = new ArrayList<>();

    // краски
    private final Paint bgPaint = new Paint();
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint tp = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint rimPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint glossPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint haloPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint shinePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint rainbowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint firePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint elecPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint flamePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint boltFill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint fireGlow = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint dashPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint boltGlow = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint boltCore = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint[] ballPaint = new Paint[NCOL];
    private final Path flamePath = new Path();
    private final Path boltPath = new Path();
    private final RectF tmp = new RectF();
    private final SimpleDateFormat dateFmt = new SimpleDateFormat("dd.MM.yy HH:mm", Locale.getDefault());

    // фоновые пузыри
    private float[] bubX, bubY, bubR, bubV;

    // соседи (переиспользуемые массивы)
    private final int[] nbR = new int[6], nbC = new int[6];

    public GameView(Context ctx) {
        super(ctx);
        store = new ScoreStore(ctx);
        bestScore = store.best();
        tp.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        setOnApplyWindowInsetsListener((v, ins) -> {
            if (Build.VERSION.SDK_INT >= 30) {
                Insets i = ins.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
                insetL = i.left;
                insetT = i.top;
                insetR = i.right;
                insetB = i.bottom;
            } else {
                insetL = ins.getSystemWindowInsetLeft();
                insetT = ins.getSystemWindowInsetTop();
                insetR = ins.getSystemWindowInsetRight();
                insetB = ins.getSystemWindowInsetBottom();
            }
            layout();
            return ins;
        });
    }

    // =====================================================================
    //  Жизненный цикл
    // =====================================================================
    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        requestApplyInsets();
        running = true;
        lastNs = System.nanoTime();
        postInvalidateOnAnimation();
    }

    @Override
    protected void onDetachedFromWindow() {
        running = false;
        super.onDetachedFromWindow();
    }

    void onHostPause() {
        if (state == S_PLAY) {
            state = S_PAUSE;
            store.commit(runId, score);
        }
        running = false;
    }

    void onHostResume() {
        running = true;
        lastNs = System.nanoTime();
        postInvalidateOnAnimation();
    }

    /** @return true, если нажатие «назад» обработано внутри игры; false — нужно закрыть приложение. */
    boolean handleBack() {
        switch (state) {
            case S_PLAY:
                state = S_PAUSE;
                aiming = false;
                store.commit(runId, score);
                return true;
            case S_PAUSE:
                resumeGame();
                return true;
            case S_OVER:
            case S_SCORES:
                state = S_MENU;
                return true;
            default:
                return false;
        }
    }

    private void resumeGame() {
        state = S_PLAY;
        lastNs = System.nanoTime();
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        W = w;
        H = h;
        layout();
    }

    // =====================================================================
    //  Раскладка
    // =====================================================================
    private void layout() {
        if (W <= 0 || H <= 0) return;
        dp = getResources().getDisplayMetrics().density;
        float margin = Math.max(insetL, insetR) + 10 * dp;
        fieldLeft = margin;
        fieldW = W - 2 * margin;
        d = fieldW / (COLS + 0.5f);
        r = d / 2f;
        rowH = d * 0.866f;
        gridTop = insetT + 88 * dp;
        shooterX = fieldLeft + fieldW / 2f;
        shooterY = H - Math.max(insetB, 12 * dp) - 16 * dp - d * 0.75f;
        maxRows = (int) ((shooterY - r - gridTop) / rowH) - 1;
        if (maxRows < 8) maxRows = 8;
        pauseR = 22 * dp;
        pauseCx = W - margin - pauseR;
        pauseCy = insetT + 44 * dp;

        bgPaint.setShader(new LinearGradient(0, 0, 0, H, 0xFF1E1146, 0xFF08132E, Shader.TileMode.CLAMP));
        buildPaints();
        buildButtons();

        if (bubX == null) {
            bubX = new float[16];
            bubY = new float[16];
            bubR = new float[16];
            bubV = new float[16];
            for (int i = 0; i < 16; i++) {
                bubX[i] = rnd.nextFloat() * W;
                bubY[i] = rnd.nextFloat() * H;
                bubR[i] = (10 + rnd.nextFloat() * 36) * dp;
                bubV[i] = (8 + rnd.nextFloat() * 22) * dp;
            }
        }
        if (!rows.isEmpty()) ensureRows(maxRows + 3);
    }

    private static int mix(int a, int b, float t) {
        int ar = (a >> 16) & 255, ag = (a >> 8) & 255, ab = a & 255;
        int br = (b >> 16) & 255, bg = (b >> 8) & 255, bb = b & 255;
        return 0xFF000000 | ((int) (ar + (br - ar) * t) << 16) | ((int) (ag + (bg - ag) * t) << 8) | (int) (ab + (bb - ab) * t);
    }

    private void buildPaints() {
        for (int i = 0; i < NCOL; i++) {
            int col = COLORS[i];
            Paint pt = new Paint(Paint.ANTI_ALIAS_FLAG);
            pt.setShader(new RadialGradient(-0.3f * r, -0.35f * r, 1.45f * r,
                    new int[]{mix(col, 0xFFFFFFFF, 0.55f), col, mix(col, 0xFF000000, 0.4f)},
                    new float[]{0f, 0.5f, 1f}, Shader.TileMode.CLAMP));
            ballPaint[i] = pt;
        }
        rimPaint.setStyle(Paint.Style.STROKE);
        rimPaint.setStrokeWidth(1.5f * dp);
        rimPaint.setColor(0x44000000);
        glossPaint.setColor(0x99FFFFFF);
        haloPaint.setStyle(Paint.Style.STROKE);
        haloPaint.setStrokeWidth(2.5f * dp);
        shinePaint.setShader(new RadialGradient(-0.3f * r, -0.35f * r, 1.45f * r,
                new int[]{0x77FFFFFF, 0x00FFFFFF, 0x55000000}, new float[]{0f, 0.5f, 1f}, Shader.TileMode.CLAMP));
        rainbowPaint.setShader(new SweepGradient(0, 0,
                new int[]{0xFFFF4D5E, 0xFFFFD23F, 0xFF3DDC84, 0xFF3AA0FF, 0xFFB45CFF, 0xFFFF4D5E}, null));
        firePaint.setShader(new RadialGradient(0, 0.1f * r, 1.2f * r,
                new int[]{0xFFFFF59D, 0xFFFF9800, 0xFFD84315}, new float[]{0f, 0.55f, 1f}, Shader.TileMode.CLAMP));
        elecPaint.setShader(new RadialGradient(0, 0, 1.2f * r,
                new int[]{0xFF80DEEA, 0xFF1E88E5, 0xFF0D1B4F}, new float[]{0f, 0.55f, 1f}, Shader.TileMode.CLAMP));
        flamePaint.setColor(0xF2FFFFFF);
        boltFill.setColor(0xFFFFEB3B);
        fireGlow.setShader(new RadialGradient(0, 0, 100f,
                new int[]{0xFFFFF176, 0xCCFF9800, 0x00FF5722}, new float[]{0f, 0.6f, 1f}, Shader.TileMode.CLAMP));
        dashPaint.setStyle(Paint.Style.STROKE);
        dashPaint.setStrokeWidth(2 * dp);
        dashPaint.setPathEffect(new DashPathEffect(new float[]{12 * dp, 9 * dp}, 0));
        boltGlow.setStyle(Paint.Style.STROKE);
        boltGlow.setStrokeWidth(10 * dp);
        boltGlow.setStrokeCap(Paint.Cap.ROUND);
        boltGlow.setColor(0x884FC3F7);
        boltCore.setStyle(Paint.Style.STROKE);
        boltCore.setStrokeWidth(3.5f * dp);
        boltCore.setStrokeCap(Paint.Cap.ROUND);
        boltCore.setColor(0xFFFFFFFF);
        tp.setShadowLayer(4 * dp, 0, 2 * dp, 0xAA000000);

        flamePath.reset();
        flamePath.moveTo(0, -0.72f * r);
        flamePath.cubicTo(0.55f * r, -0.2f * r, 0.62f * r, 0.45f * r, 0, 0.62f * r);
        flamePath.cubicTo(-0.62f * r, 0.45f * r, -0.55f * r, -0.2f * r, 0, -0.72f * r);
        flamePath.close();

        boltPath.reset();
        boltPath.moveTo(0.18f * r, -0.78f * r);
        boltPath.lineTo(-0.42f * r, 0.08f * r);
        boltPath.lineTo(-0.04f * r, 0.08f * r);
        boltPath.lineTo(-0.2f * r, 0.78f * r);
        boltPath.lineTo(0.44f * r, -0.14f * r);
        boltPath.lineTo(0.06f * r, -0.14f * r);
        boltPath.close();
    }

    private Btn mk(ArrayList<Btn> l, int id, String label, float cx, float cy, float w, float h) {
        Btn b = new Btn();
        b.id = id;
        b.label = label;
        b.r.set(cx - w / 2, cy - h / 2, cx + w / 2, cy + h / 2);
        l.add(b);
        return b;
    }

    private void buildButtons() {
        menuBtns.clear();
        overBtns.clear();
        scoreBtns.clear();
        pauseBtns.clear();
        float bw = Math.min(W * 0.72f, 320 * dp), bh = 58 * dp, cx = W / 2f, gap = bh * 1.3f;
        float y0 = H * 0.54f;
        mk(menuBtns, B_PLAY, "ИГРАТЬ", cx, y0, bw, bh);
        mk(menuBtns, B_SCORES, "ТОП-10", cx, y0 + gap, bw, bh);
        mk(menuBtns, B_EXIT, "ВЫХОД", cx, y0 + 2 * gap, bw, bh);
        float oy = H * 0.5f + 90 * dp;
        mk(overBtns, B_AGAIN, "ИГРАТЬ СНОВА", cx, oy, bw, bh);
        mk(overBtns, B_MENU, "МЕНЮ", cx, oy + gap, bw, bh);
        mk(scoreBtns, B_BACK, "НАЗАД", cx, H - Math.max(insetB, 12 * dp) - 44 * dp, bw, bh);
        mk(pauseBtns, B_RESUME, "ПРОДОЛЖИТЬ", cx, H * 0.44f, bw, bh);
        mk(pauseBtns, B_MENU, "В МЕНЮ", cx, H * 0.44f + gap, bw, bh);
    }

    // =====================================================================
    //  Сетка
    // =====================================================================
    private int off(int row) {
        return (row + parity) & 1;
    }

    private float cellX(int row, int col) {
        return fieldLeft + r + col * d + (off(row) == 1 ? r : 0f);
    }

    private float cellY(int row) {
        return gridTop + r + row * rowH;
    }

    private void ensureRows(int n) {
        while (rows.size() < n) rows.add(new Row());
    }

    private void fillRow(Row row) {
        for (int c = 0; c < COLS; c++) {
            row.t[c] = (c > 0 && rnd.nextFloat() < 0.4f) ? row.t[c - 1] : rnd.nextInt(NCOL);
            row.pulse[c] = 0f;
        }
    }

    /** Заполняет nbR/nbC соседями ячейки, возвращает их число. */
    private int neighbors(int rr, int cc) {
        int n = 0;
        if (cc > 0) {
            nbR[n] = rr;
            nbC[n++] = cc - 1;
        }
        if (cc < COLS - 1) {
            nbR[n] = rr;
            nbC[n++] = cc + 1;
        }
        int c1 = off(rr) == 1 ? cc : cc - 1;
        int c2 = c1 + 1;
        for (int dr = -1; dr <= 1; dr += 2) {
            int r2 = rr + dr;
            if (r2 < 0 || r2 >= rows.size()) continue;
            if (c1 >= 0 && c1 < COLS) {
                nbR[n] = r2;
                nbC[n++] = c1;
            }
            if (c2 >= 0 && c2 < COLS) {
                nbR[n] = r2;
                nbC[n++] = c2;
            }
        }
        return n;
    }

    private boolean hasSupport(int rr, int cc) {
        if (rr == 0) return true;
        int n = neighbors(rr, cc);
        for (int i = 0; i < n; i++) if (rows.get(nbR[i]).t[nbC[i]] >= 0) return true;
        return false;
    }

    private int hitBall(float x, float y) {
        float lim = d * 0.86f;
        int r0 = Math.round((y - gridTop - r) / rowH);
        for (int rr = r0 - 1; rr <= r0 + 1; rr++) {
            if (rr < 0 || rr >= rows.size()) continue;
            float cy = cellY(rr);
            if (Math.abs(cy - y) > lim) continue;
            Row row = rows.get(rr);
            for (int c = 0; c < COLS; c++) {
                if (row.t[c] < 0) continue;
                float dx = cellX(rr, c) - x, dy = cy - y;
                if (dx * dx + dy * dy < lim * lim) return rr * COLS + c;
            }
        }
        return -1;
    }

    private int[] snapCell(float x, float y) {
        ensureRows(maxRows + 3);
        int r0 = Math.round((y - gridTop - r) / rowH);
        float best = Float.MAX_VALUE;
        int br = -1, bc = -1;
        for (int pass = 1; pass <= 3 && br < 0; pass++) {
            for (int rr = r0 - pass; rr <= r0 + pass; rr++) {
                if (rr < 0 || rr >= rows.size()) continue;
                Row row = rows.get(rr);
                float cy = cellY(rr);
                for (int cc = 0; cc < COLS; cc++) {
                    if (row.t[cc] >= 0 || !hasSupport(rr, cc)) continue;
                    float dx = cellX(rr, cc) - x, dy = cy - y;
                    float dd = dx * dx + dy * dy;
                    if (dd < best) {
                        best = dd;
                        br = rr;
                        bc = cc;
                    }
                }
            }
        }
        if (br < 0) {
            br = 0;
            bc = 0;
            for (int cc = 0; cc < COLS; cc++) {
                if (rows.get(0).t[cc] < 0) {
                    bc = cc;
                    break;
                }
            }
        }
        return new int[]{br, bc};
    }

    private ArrayList<Integer> flood(int rr, int cc, int color) {
        boolean[] seen = new boolean[rows.size() * COLS];
        ArrayList<Integer> out = new ArrayList<>();
        ArrayDeque<Integer> q = new ArrayDeque<>();
        q.add(rr * COLS + cc);
        seen[rr * COLS + cc] = true;
        while (!q.isEmpty()) {
            int id = q.poll();
            out.add(id);
            int n = neighbors(id / COLS, id % COLS);
            for (int i = 0; i < n; i++) {
                int nid = nbR[i] * COLS + nbC[i];
                if (!seen[nid] && rows.get(nbR[i]).t[nbC[i]] == color) {
                    seen[nid] = true;
                    q.add(nid);
                }
            }
        }
        return out;
    }

    private int rainbowColor(int rr, int cc) {
        int n = neighbors(rr, cc);
        ArrayList<Integer> cand = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            int t = rows.get(nbR[i]).t[nbC[i]];
            if (t >= 0 && t < NCOL && !cand.contains(t)) cand.add(t);
        }
        int best = -1, bestSize = -1;
        for (int col : cand) {
            rows.get(rr).t[cc] = col;
            int sz = flood(rr, cc, col).size();
            if (sz > bestSize) {
                bestSize = sz;
                best = col;
            }
        }
        if (best < 0) best = rnd.nextInt(NCOL);
        return best;
    }

    private int removeFloating() {
        boolean[] seen = new boolean[rows.size() * COLS];
        ArrayDeque<Integer> q = new ArrayDeque<>();
        for (int cc = 0; cc < COLS; cc++) {
            if (rows.get(0).t[cc] >= 0) {
                seen[cc] = true;
                q.add(cc);
            }
        }
        while (!q.isEmpty()) {
            int id = q.poll();
            int n = neighbors(id / COLS, id % COLS);
            for (int i = 0; i < n; i++) {
                int nid = nbR[i] * COLS + nbC[i];
                if (!seen[nid] && rows.get(nbR[i]).t[nbC[i]] >= 0) {
                    seen[nid] = true;
                    q.add(nid);
                }
            }
        }
        int count = 0;
        float sx = 0, sy = 0;
        for (int rr = 0; rr < rows.size(); rr++) {
            Row row = rows.get(rr);
            for (int cc = 0; cc < COLS; cc++) {
                if (row.t[cc] >= 0 && !seen[rr * COLS + cc]) {
                    Fx f = addFx(FX_FALL, cellX(rr, cc), cellY(rr), 3f, 0);
                    f.color = row.t[cc];
                    f.vx = (rnd.nextFloat() - 0.5f) * d * 3f;
                    f.vy = -rnd.nextFloat() * d * 3f;
                    row.t[cc] = -1;
                    count++;
                    sx += f.x;
                    sy += f.y;
                }
            }
        }
        if (count > 0) addScore(count * 25, sx / count, sy / count);
        return count;
    }

    private boolean boardEmpty() {
        for (Row row : rows) for (int c = 0; c < COLS; c++) if (row.t[c] >= 0) return false;
        return true;
    }

    private boolean checkLose() {
        for (int rr = maxRows; rr < rows.size(); rr++) {
            for (int c = 0; c < COLS; c++) if (rows.get(rr).t[c] >= 0) return true;
        }
        return false;
    }

    private void addTopRow() {
        Row nr = new Row();
        fillRow(nr);
        rows.add(0, nr);
        parity ^= 1;
        ensureRows(maxRows + 3);
        while (rows.size() > maxRows + 4) {
            Row last = rows.get(rows.size() - 1);
            boolean empty = true;
            for (int c = 0; c < COLS; c++) if (last.t[c] >= 0) empty = false;
            if (!empty) break;
            rows.remove(rows.size() - 1);
        }
    }

    // =====================================================================
    //  Игра
    // =====================================================================
    private void newGame() {
        rows.clear();
        fx.clear();
        parity = 0;
        for (int i = 0; i < START_ROWS; i++) {
            Row row = new Row();
            fillRow(row);
            rows.add(row);
        }
        ensureRows(maxRows + 3);
        score = 0;
        shots = 0;
        rank = -1;
        runId = System.currentTimeMillis();
        sinceBoost = 0;
        descAnim = 0;
        phase = P_AIM;
        aiming = false;
        shake = 0;
        flash = 0;
        curType = randomBall();
        nextType = randomBall();
        reloadT = 0f;
        state = S_PLAY;
        lastNs = System.nanoTime();
    }

    private int randomBall() {
        sinceBoost++;
        if (sinceBoost >= SINCE_BOOST_MIN && rnd.nextFloat() < BOOST_CHANCE) {
            sinceBoost = 0;
            return NCOL + rnd.nextInt(3);
        }
        boolean[] present = new boolean[NCOL];
        int cnt = 0;
        for (Row row : rows) {
            for (int c = 0; c < COLS; c++) {
                int t = row.t[c];
                if (t >= 0 && t < NCOL && !present[t]) {
                    present[t] = true;
                    cnt++;
                }
            }
        }
        if (cnt == 0) return rnd.nextInt(NCOL);
        int k = rnd.nextInt(cnt);
        for (int i = 0; i < NCOL; i++) {
            if (present[i]) {
                if (k == 0) return i;
                k--;
            }
        }
        return 0;
    }

    private void loadNext() {
        curType = nextType;
        nextType = randomBall();
        reloadT = 0f;
    }

    private void fire() {
        shotType = curType;
        shotX = shooterX;
        shotY = shooterY;
        shotDX = (float) Math.cos(aimAng);
        shotDY = -(float) Math.sin(aimAng);
        trailN = 0;
        curType = -1;
        phase = P_FLY;
        shots++;
    }

    private void updateShot(float dt) {
        float speed = SHOT_SPEED_H * H;
        float dist = speed * dt;
        int n = (int) Math.ceil(dist / (d * 0.25f));
        if (n < 1) n = 1;
        float sd = dist / n;
        float minX = fieldLeft + r, maxX = fieldLeft + fieldW - r;
        for (int i = 0; i < n; i++) {
            shotX += shotDX * sd;
            shotY += shotDY * sd;
            if (shotX < minX) {
                shotX = minX + (minX - shotX);
                shotDX = -shotDX;
            } else if (shotX > maxX) {
                shotX = maxX - (shotX - maxX);
                shotDX = -shotDX;
            }
            int h = hitBall(shotX, shotY);
            if (h >= 0) {
                land(h / COLS, h % COLS);
                return;
            }
            if (shotY <= gridTop + r) {
                land(-1, -1);
                return;
            }
        }
        for (int i = trailX.length - 1; i > 0; i--) {
            trailX[i] = trailX[i - 1];
            trailY[i] = trailY[i - 1];
        }
        trailX[0] = shotX;
        trailY[0] = shotY;
        if (trailN < trailX.length) trailN++;
    }

    private void land(int hr, int hc) {
        ensureRows(maxRows + 3);
        int type = shotType;
        float lx = shotX, ly = shotY;
        boolean popped;
        if (type == T_FIRE) {
            popped = doFire(hr, hc, lx, ly);
        } else if (type == T_ELEC) {
            popped = doElectric(hr, lx, ly);
        } else {
            popped = doAttach(type, lx, ly);
        }
        if (popped) {
            removeFloating();
            if (boardEmpty()) {
                score += 300;
                addText(W / 2f, gridTop + 4 * d, "ЧИСТО! +300", 0xFFFFEB3B, 30 * dp);
                for (int i = 0; i < START_ROWS; i++) {
                    Row row = rows.get(i);
                    fillRow(row);
                    Arrays.fill(row.pulse, 1f);
                }
            }
            phase = P_AIM;
            loadNext();
            if (checkLose()) gameOver();
        } else {
            if (checkLose()) {
                gameOver();
                return;
            }
            addTopRow();
            descAnim = 1f;
            phase = P_DESC;
            loadNext();
        }
    }

    private boolean doAttach(int type, float lx, float ly) {
        int[] cell = snapCell(lx, ly);
        int rr = cell[0], cc = cell[1];
        int color = type;
        if (type == T_RAINBOW) color = rainbowColor(rr, cc);
        Row row = rows.get(rr);
        row.t[cc] = color;
        row.pulse[cc] = 1f;
        ArrayList<Integer> grp = flood(rr, cc, color);
        if (grp.size() < 3) return false;
        float cx = cellX(rr, cc), cy = cellY(rr);
        int n = grp.size();
        for (int id : grp) {
            int gr = id / COLS, gc = id % COLS;
            float x = cellX(gr, gc), y = cellY(gr);
            float dist = (float) Math.hypot(x - cx, y - cy);
            popFx(rows.get(gr).t[gc], x, y, dist / d * 0.045f);
            rows.get(gr).t[gc] = -1;
        }
        addScore(n * 10 + (n - 3) * 10, cx, cy);
        performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP);
        return true;
    }

    private boolean doFire(int hr, int hc, float lx, float ly) {
        float cx = hr >= 0 ? cellX(hr, hc) : lx;
        float cy = hr >= 0 ? cellY(hr) : ly;
        float rad = FIRE_RADIUS * d + 1f;
        int n = 0;
        for (int rr = 0; rr < rows.size(); rr++) {
            Row row = rows.get(rr);
            for (int cc = 0; cc < COLS; cc++) {
                if (row.t[cc] < 0) continue;
                float x = cellX(rr, cc), y = cellY(rr);
                float dist = (float) Math.hypot(x - cx, y - cy);
                if (dist <= rad) {
                    popFx(row.t[cc], x, y, dist / rad * 0.2f);
                    row.t[cc] = -1;
                    n++;
                }
            }
        }
        Fx f = addFx(FX_RING, cx, cy, 0.6f, 0);
        f.size = rad;
        shake = 0.45f;
        flash = 0.45f;
        flashColor = 0xFFFFB74D;
        if (n > 0) addScore(n * 15, cx, cy);
        performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
        return n > 0;
    }

    private boolean doElectric(int hr, float lx, float ly) {
        int row = hr >= 0 ? hr : 0;
        float ry = cellY(row);
        Row rw = rows.get(row);
        int n = 0;
        for (int cc = 0; cc < COLS; cc++) {
            if (rw.t[cc] >= 0) {
                float x = cellX(row, cc);
                popFx(rw.t[cc], x, ry, Math.abs(x - lx) / fieldW * 0.25f);
                rw.t[cc] = -1;
                n++;
            }
        }
        Fx b = addFx(FX_BOLT, lx, ry, 0.5f, 0);
        b.lines = new float[][]{
                zig(lx, ly, lx, ry, 5, d * 0.25f),
                zig(lx, ry, fieldLeft, ry, 12, d * 0.3f),
                zig(lx, ry, fieldLeft + fieldW, ry, 12, d * 0.3f)};
        flash = 0.4f;
        flashColor = 0xFFB3E5FC;
        shake = 0.25f;
        if (n > 0) addScore(n * 12, lx, ry - d);
        performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
        return n > 0;
    }

    private float[] zig(float x0, float y0, float x1, float y1, int steps, float amp) {
        float[] pts = new float[(steps + 1) * 2];
        float dx = x1 - x0, dy = y1 - y0;
        float len = (float) Math.hypot(dx, dy);
        float nx = len > 0 ? -dy / len : 0, ny = len > 0 ? dx / len : 0;
        for (int i = 0; i <= steps; i++) {
            float t = i / (float) steps;
            float j = (i == 0 || i == steps) ? 0 : (rnd.nextFloat() - 0.5f) * 2f * amp;
            pts[2 * i] = x0 + dx * t + nx * j;
            pts[2 * i + 1] = y0 + dy * t + ny * j;
        }
        float[] seg = new float[steps * 4];
        for (int i = 0; i < steps; i++) {
            seg[4 * i] = pts[2 * i];
            seg[4 * i + 1] = pts[2 * i + 1];
            seg[4 * i + 2] = pts[2 * i + 2];
            seg[4 * i + 3] = pts[2 * i + 3];
        }
        return seg;
    }

    private void gameOver() {
        if (state == S_OVER) return;
        state = S_OVER;
        overT = 0;
        phase = P_AIM;
        aiming = false;
        store.commit(runId, score);
        bestScore = Math.max(bestScore, score);
        rank = store.rankOf(runId);
        highlightRun = runId;
        float o = rowH * descAnim * descAnim;
        for (int rr = 0; rr < rows.size(); rr++) {
            Row row = rows.get(rr);
            for (int cc = 0; cc < COLS; cc++) {
                if (row.t[cc] < 0) continue;
                Fx f = addFx(FX_FALL, cellX(rr, cc), cellY(rr) - o, 3f, rr * 0.02f + rnd.nextFloat() * 0.15f);
                f.color = row.t[cc];
                f.vx = (rnd.nextFloat() - 0.5f) * d * 3f;
                f.vy = -rnd.nextFloat() * d * 4f;
                row.t[cc] = -1;
            }
        }
        shake = 0.5f;
        performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
    }

    // =====================================================================
    //  Эффекты
    // =====================================================================
    private Fx addFx(int kind, float x, float y, float life, float delay) {
        Fx f = new Fx();
        f.kind = kind;
        f.x = x;
        f.y = y;
        f.life = life;
        f.delay = delay;
        fx.add(f);
        return f;
    }

    private void popFx(int type, float x, float y, float delay) {
        Fx f = addFx(FX_POP, x, y, 0.24f, delay);
        f.color = type;
        for (int i = 0; i < 6; i++) {
            Fx q = addFx(FX_PART, x, y, 0.5f + rnd.nextFloat() * 0.3f, delay);
            float a = rnd.nextFloat() * 6.2832f;
            float sp = (0.4f + rnd.nextFloat() * 0.9f) * d * 5f;
            q.vx = (float) Math.cos(a) * sp;
            q.vy = (float) Math.sin(a) * sp - d * 2f;
            q.size = r * (0.18f + 0.2f * rnd.nextFloat());
            q.color = type < NCOL ? COLORS[type] : 0xFFFFFFFF;
        }
    }

    private void addText(float x, float y, String s, int color, float size) {
        Fx f = addFx(FX_TEXT, x, y, 0.95f, 0);
        f.text = s;
        f.color = color;
        f.size = size;
    }

    private void addScore(int pts, float x, float y) {
        score += pts;
        addText(x, y, "+" + pts, 0xFFFFFFFF, 26 * dp);
    }

    private void updateFx(float dt) {
        for (int i = fx.size() - 1; i >= 0; i--) {
            Fx f = fx.get(i);
            if (f.delay > 0) {
                f.delay -= dt;
                continue;
            }
            f.t += dt;
            switch (f.kind) {
                case FX_PART:
                    f.vx *= (1f - 2.5f * dt);
                    f.vy += d * 7f * dt;
                    f.x += f.vx * dt;
                    f.y += f.vy * dt;
                    break;
                case FX_FALL:
                    f.vy += d * 26f * dt;
                    f.x += f.vx * dt;
                    f.y += f.vy * dt;
                    if (f.y > H + d) fx.remove(i);
                    continue;
                case FX_TEXT:
                    f.y -= 90 * dp * dt;
                    break;
                default:
                    break;
            }
            if (f.t >= f.life) fx.remove(i);
        }
    }

    // =====================================================================
    //  Цикл обновления
    // =====================================================================
    private void update(float dt) {
        time += dt;
        if (bubX != null) {
            for (int i = 0; i < bubX.length; i++) {
                bubY[i] -= bubV[i] * dt;
                if (bubY[i] < -bubR[i]) {
                    bubY[i] = H + bubR[i];
                    bubX[i] = rnd.nextFloat() * W;
                }
            }
        }
        if (state == S_PAUSE) return;
        if (state == S_PLAY) {
            reloadT = Math.min(1f, reloadT + dt / 0.18f);
            if (phase == P_FLY) {
                updateShot(dt);
            } else if (phase == P_DESC) {
                descAnim -= dt / 0.32f;
                if (descAnim <= 0f) {
                    descAnim = 0f;
                    phase = P_AIM;
                    if (checkLose()) gameOver();
                }
            }
            for (Row row : rows) {
                for (int c = 0; c < COLS; c++) if (row.pulse[c] > 0f) row.pulse[c] = Math.max(0f, row.pulse[c] - dt * 4f);
            }
        }
        if (state == S_OVER) overT += dt;
        updateFx(dt);
        shake = Math.max(0f, shake - dt * 1.8f);
        flash = Math.max(0f, flash - dt * 3f);
    }

    // =====================================================================
    //  Отрисовка
    // =====================================================================
    @Override
    protected void onDraw(Canvas c) {
        long now = System.nanoTime();
        float dt = (now - lastNs) / 1e9f;
        lastNs = now;
        if (dt > 0.05f) dt = 0.05f;
        if (dt < 0f) dt = 0f;
        if (W > 0 && H > 0 && d > 0) {
            update(dt);
            c.drawPaint(bgPaint);
            drawBubbles(c);
            switch (state) {
                case S_MENU:
                    drawMenu(c);
                    break;
                case S_SCORES:
                    drawScores(c);
                    break;
                default:
                    drawPlay(c);
                    if (state == S_PAUSE) drawPause(c);
                    if (state == S_OVER) drawOver(c);
                    break;
            }
        }
        if (running) postInvalidateOnAnimation();
    }

    private void drawBubbles(Canvas c) {
        if (bubX == null) return;
        p.setStyle(Paint.Style.FILL);
        p.setShader(null);
        for (int i = 0; i < bubX.length; i++) {
            p.setColor(0x0DFFFFFF);
            c.drawCircle(bubX[i], bubY[i], bubR[i], p);
        }
    }

    private void text(Canvas c, String s, float x, float y, float size, int color, Paint.Align a) {
        tp.setTextSize(size);
        tp.setColor(color);
        tp.setTextAlign(a);
        c.drawText(s, x, y, tp);
    }

    private void drawBall(Canvas c, int type, float x, float y, float s) {
        if (s <= 0.01f || type < 0) return;
        c.save();
        c.translate(x, y);
        c.scale(s, s);
        if (type < NCOL) {
            c.drawCircle(0, 0, r, ballPaint[type]);
            c.drawCircle(-0.33f * r, -0.38f * r, 0.2f * r, glossPaint);
            c.drawCircle(0, 0, r, rimPaint);
        } else if (type == T_RAINBOW) {
            haloPaint.setColor(0xAAFFFFFF);
            c.drawCircle(0, 0, r * (1.12f + 0.05f * (float) Math.sin(time * 7)), haloPaint);
            c.save();
            c.rotate(time * 140f);
            c.drawCircle(0, 0, r, rainbowPaint);
            c.restore();
            c.drawCircle(0, 0, r, shinePaint);
            c.drawCircle(0, 0, r, rimPaint);
        } else if (type == T_FIRE) {
            haloPaint.setColor(0xAAFF9800);
            c.drawCircle(0, 0, r * (1.12f + 0.05f * (float) Math.sin(time * 7)), haloPaint);
            c.drawCircle(0, 0, r, firePaint);
            c.save();
            float fs = 1f + 0.08f * (float) Math.sin(time * 12);
            c.scale(fs, fs);
            c.drawPath(flamePath, flamePaint);
            c.restore();
            c.drawCircle(0, 0, r, shinePaint);
            c.drawCircle(0, 0, r, rimPaint);
        } else {
            haloPaint.setColor(0xAA4FC3F7);
            c.drawCircle(0, 0, r * (1.12f + 0.05f * (float) Math.sin(time * 7)), haloPaint);
            c.drawCircle(0, 0, r, elecPaint);
            c.drawPath(boltPath, boltFill);
            c.drawCircle(0, 0, r, shinePaint);
            c.drawCircle(0, 0, r, rimPaint);
        }
        c.restore();
    }

    private void drawPlay(Canvas c) {
        c.save();
        if (shake > 0f) {
            float s = shake * 14 * dp;
            c.translate((rnd.nextFloat() - 0.5f) * s, (rnd.nextFloat() - 0.5f) * s);
        }
        drawField(c);

        // шары сетки
        float o = rowH * descAnim * descAnim;
        c.save();
        c.clipRect(0, gridTop, W, H);
        for (int rr = 0; rr < rows.size(); rr++) {
            float y = cellY(rr) - o;
            if (y < gridTop - d || y > shooterY) continue;
            Row row = rows.get(rr);
            for (int cc = 0; cc < COLS; cc++) {
                int t = row.t[cc];
                if (t < 0) continue;
                float s = 1f + 0.18f * (float) Math.sin(row.pulse[cc] * Math.PI);
                drawBall(c, t, cellX(rr, cc), y, s);
            }
        }
        c.restore();

        drawFx(c);
        drawShooter(c);
        c.restore();

        if (flash > 0f) {
            p.setStyle(Paint.Style.FILL);
            p.setShader(null);
            p.setColor((flashColor & 0x00FFFFFF) | ((int) (flash * 200) << 24));
            c.drawRect(0, 0, W, H, p);
        }
        drawHud(c);
    }

    private void drawField(Canvas c) {
        p.setShader(null);
        // боковые линии
        p.setStyle(Paint.Style.FILL);
        p.setColor(0x14FFFFFF);
        c.drawRect(fieldLeft - 3 * dp, gridTop, fieldLeft, shooterY + r, p);
        c.drawRect(fieldLeft + fieldW, gridTop, fieldLeft + fieldW + 3 * dp, shooterY + r, p);
        // потолок
        p.setColor(0x55FFFFFF);
        tmp.set(fieldLeft - 3 * dp, gridTop - 9 * dp, fieldLeft + fieldW + 3 * dp, gridTop);
        c.drawRoundRect(tmp, 4 * dp, 4 * dp, p);
        // линия опасности
        float ly = gridTop + (maxRows - 1) * rowH + d + 2 * dp;
        boolean danger = false;
        for (int rr = Math.max(0, maxRows - 3); rr < rows.size() && !danger; rr++) {
            for (int cc = 0; cc < COLS; cc++) {
                if (rows.get(rr).t[cc] >= 0) {
                    danger = true;
                    break;
                }
            }
        }
        int a = danger ? (int) (110 + 90 * Math.sin(time * 8)) : 70;
        dashPaint.setColor((0xFF5252) | (a << 24));
        c.drawLine(fieldLeft, ly, fieldLeft + fieldW, ly, dashPaint);
    }

    private void drawShooter(Canvas c) {
        // основание
        p.setStyle(Paint.Style.FILL);
        p.setShader(null);
        p.setColor(0x33000000);
        c.drawCircle(shooterX, shooterY, d * 1.1f, p);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(3 * dp);
        p.setColor(0x44FFFFFF);
        c.drawCircle(shooterX, shooterY, d * 1.1f, p);

        // ствол
        float ang = aiming && aimValid ? aimAng : (float) (Math.PI / 2);
        c.save();
        c.translate(shooterX, shooterY);
        c.rotate(90f - (float) Math.toDegrees(ang));
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xFF34457F);
        tmp.set(-0.3f * d, -1.35f * d, 0.3f * d, 0f);
        c.drawRoundRect(tmp, 0.18f * d, 0.18f * d, p);
        p.setColor(0xFF5B73C7);
        tmp.set(-0.3f * d, -1.35f * d, 0.3f * d, -1.1f * d);
        c.drawRoundRect(tmp, 0.12f * d, 0.12f * d, p);
        c.restore();

        // заряженный шар
        if (phase != P_FLY && curType >= 0) {
            float s = reloadT * reloadT * (3f - 2f * reloadT);
            drawBall(c, curType, shooterX, shooterY, s);
        }
        // следующий шар
        float nx = shooterX - 2.5f * d, ny = shooterY + 0.1f * d;
        p.setStyle(Paint.Style.FILL);
        p.setColor(0x33000000);
        c.drawCircle(nx, ny, r * 0.95f, p);
        drawBall(c, nextType, nx, ny, 0.72f);

        // прицел
        if (aiming && aimValid && phase == P_AIM) {
            p.setStyle(Paint.Style.FILL);
            for (int i = 0; i < aimN; i++) {
                int a = (int) (200 - 120f * i / Math.max(1, aimN));
                p.setColor(0x00FFFFFF | (a << 24));
                c.drawCircle(aimPts[2 * i], aimPts[2 * i + 1], d * 0.085f, p);
            }
            if (ghostOn) {
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeWidth(2.5f * dp);
                p.setColor(0x99FFFFFF);
                c.drawCircle(ghostX, ghostY, r * 0.95f, p);
            }
        }

        // летящий шар и след
        if (phase == P_FLY) {
            p.setStyle(Paint.Style.FILL);
            for (int i = trailN - 1; i >= 0; i--) {
                float k = 1f - (i + 1f) / (trailX.length + 1f);
                int col = shotType < NCOL ? COLORS[shotType] : 0xFFFFFFFF;
                p.setColor((col & 0x00FFFFFF) | ((int) (90 * k) << 24));
                c.drawCircle(trailX[i], trailY[i], r * k, p);
            }
            drawBall(c, shotType, shotX, shotY, 1f);
        }

        // подсказка
        if (shots == 0 && state == S_PLAY && phase == P_AIM) {
            text(c, "Тяните и отпустите, чтобы выстрелить", W / 2f, shooterY - 2.4f * d, 15 * dp, 0xBBFFFFFF, Paint.Align.CENTER);
        }
    }

    private void drawFx(Canvas c) {
        for (int i = 0; i < fx.size(); i++) {
            Fx f = fx.get(i);
            if (f.delay > 0f) {
                if (f.kind == FX_POP || f.kind == FX_FALL) drawBall(c, f.color, f.x, f.y, 1f);
                continue;
            }
            float pr = Math.min(1f, f.t / f.life);
            switch (f.kind) {
                case FX_POP: {
                    float s = pr < 0.3f ? 1f + 0.3f * (pr / 0.3f) : 1.3f * (1f - (pr - 0.3f) / 0.7f);
                    drawBall(c, f.color, f.x, f.y, Math.max(0f, s));
                    break;
                }
                case FX_PART:
                    p.setStyle(Paint.Style.FILL);
                    p.setShader(null);
                    p.setColor((f.color & 0x00FFFFFF) | ((int) ((1f - pr) * 255) << 24));
                    c.drawCircle(f.x, f.y, f.size * (1f - pr * 0.7f), p);
                    break;
                case FX_FALL:
                    drawBall(c, f.color, f.x, f.y, 1f);
                    break;
                case FX_RING: {
                    float e = 1f - (1f - pr) * (1f - pr);
                    float rad = f.size * e;
                    c.save();
                    c.translate(f.x, f.y);
                    c.scale(rad / 100f, rad / 100f);
                    fireGlow.setAlpha((int) ((1f - pr) * 255));
                    c.drawCircle(0, 0, 100f, fireGlow);
                    c.restore();
                    p.setStyle(Paint.Style.STROKE);
                    p.setStrokeWidth(6 * dp);
                    p.setColor(0x00FFFFFF | ((int) ((1f - pr) * 220) << 24));
                    c.drawCircle(f.x, f.y, rad, p);
                    break;
                }
                case FX_BOLT:
                    if (f.lines != null && ((int) (f.t * 30f) % 3) != 2) {
                        int a = (int) ((1f - pr) * 255);
                        boltGlow.setAlpha(Math.min(136, a));
                        boltCore.setAlpha(a);
                        for (float[] ln : f.lines) {
                            c.drawLines(ln, boltGlow);
                            c.drawLines(ln, boltCore);
                        }
                    }
                    break;
                case FX_TEXT: {
                    float s = Math.min(1f, f.t / 0.12f);
                    int a = pr < 0.6f ? 255 : (int) ((1f - pr) / 0.4f * 255);
                    text(c, f.text, f.x, f.y, f.size * (0.6f + 0.4f * s), (f.color & 0x00FFFFFF) | (a << 24), Paint.Align.CENTER);
                    break;
                }
                default:
                    break;
            }
        }
    }

    private void drawHud(Canvas c) {
        text(c, String.valueOf(score), W / 2f, insetT + 54 * dp, 40 * dp, 0xFFFFFFFF, Paint.Align.CENTER);
        text(c, "РЕКОРД " + Math.max(bestScore, score), W / 2f, insetT + 74 * dp, 13 * dp, 0xAAFFFFFF, Paint.Align.CENTER);
        p.setShader(null);
        p.setStyle(Paint.Style.FILL);
        p.setColor(pauseDown ? 0x66FFFFFF : 0x33FFFFFF);
        c.drawCircle(pauseCx, pauseCy, pauseR, p);
        p.setColor(0xFFFFFFFF);
        float bw = 4 * dp, bh = 14 * dp;
        tmp.set(pauseCx - 7 * dp, pauseCy - bh / 2, pauseCx - 7 * dp + bw, pauseCy + bh / 2);
        c.drawRoundRect(tmp, 2 * dp, 2 * dp, p);
        tmp.set(pauseCx + 3 * dp, pauseCy - bh / 2, pauseCx + 3 * dp + bw, pauseCy + bh / 2);
        c.drawRoundRect(tmp, 2 * dp, 2 * dp, p);
    }

    private void drawBtn(Canvas c, Btn b) {
        c.save();
        if (b.down) c.scale(0.96f, 0.96f, b.r.centerX(), b.r.centerY());
        boolean prim = b.id == B_PLAY || b.id == B_AGAIN || b.id == B_RESUME;
        p.setStyle(Paint.Style.FILL);
        p.setShader(new LinearGradient(b.r.left, b.r.top, b.r.right, b.r.bottom,
                prim ? 0xFF7C4DFF : 0xFF34457F, prim ? 0xFF2979FF : 0xFF22305F, Shader.TileMode.CLAMP));
        c.drawRoundRect(b.r, b.r.height() / 2, b.r.height() / 2, p);
        p.setShader(null);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(1.5f * dp);
        p.setColor(0x55FFFFFF);
        c.drawRoundRect(b.r, b.r.height() / 2, b.r.height() / 2, p);
        text(c, b.label, b.r.centerX(), b.r.centerY() + 7 * dp, 20 * dp, 0xFFFFFFFF, Paint.Align.CENTER);
        c.restore();
    }

    private void drawMenu(Canvas c) {
        text(c, "BALL", W / 2f, H * 0.2f, 72 * dp, 0xFFFFFFFF, Paint.Align.CENTER);
        text(c, "BURST", W / 2f, H * 0.2f + 76 * dp, 72 * dp, 0xFFFFD23F, Paint.Align.CENTER);
        float y = H * 0.40f;
        for (int i = 0; i < NCOL; i++) {
            float x = W / 2f + (i - 2) * d * 1.15f;
            drawBall(c, i, x, y + 10 * dp * (float) Math.sin(time * 3 + i), 1f);
        }
        for (Btn b : menuBtns) drawBtn(c, b);
        text(c, "Рекорд: " + bestScore, W / 2f, H * 0.54f + 3.9f * 58 * dp + 20 * dp, 14 * dp, 0x88FFFFFF, Paint.Align.CENTER);
    }

    private void drawPause(Canvas c) {
        p.setShader(null);
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xAA000000);
        c.drawRect(0, 0, W, H, p);
        text(c, "ПАУЗА", W / 2f, H * 0.44f - 80 * dp, 44 * dp, 0xFFFFFFFF, Paint.Align.CENTER);
        for (Btn b : pauseBtns) drawBtn(c, b);
    }

    private void drawOver(Canvas c) {
        float a = Math.min(1f, Math.max(0f, (overT - 0.5f) / 0.5f));
        if (a <= 0f) return;
        p.setShader(null);
        p.setStyle(Paint.Style.FILL);
        p.setColor(((int) (a * 170) << 24));
        c.drawRect(0, 0, W, H, p);
        c.save();
        c.translate(0, (1f - a) * 40 * dp);
        text(c, "ИГРА ОКОНЧЕНА", W / 2f, H * 0.5f - 150 * dp, 32 * dp, 0xFFFFFFFF, Paint.Align.CENTER);
        text(c, String.valueOf(score), W / 2f, H * 0.5f - 70 * dp, 64 * dp, 0xFFFFD23F, Paint.Align.CENTER);
        String sub;
        if (rank == 1 && score > 0) sub = "Новый рекорд!";
        else if (rank > 0) sub = "Место в топ-10: " + rank;
        else sub = "Рекорд: " + bestScore;
        text(c, sub, W / 2f, H * 0.5f - 25 * dp, 18 * dp, 0xFFFFFFFF, Paint.Align.CENTER);
        if (overT > 0.8f) for (Btn b : overBtns) drawBtn(c, b);
        c.restore();
    }

    private void drawScores(Canvas c) {
        text(c, "ТОП-10", W / 2f, insetT + 70 * dp, 40 * dp, 0xFFFFFFFF, Paint.Align.CENTER);
        List<ScoreStore.Entry> list = store.load();
        float top = insetT + 100 * dp;
        float bottom = scoreBtns.get(0).r.top - 16 * dp;
        float rh = Math.min(56 * dp, (bottom - top) / 10f);
        float left = Math.max(insetL, 0) + 20 * dp, right = W - Math.max(insetR, 0) - 20 * dp;
        int[] medal = {0xFFFFD54F, 0xFFCFD8DC, 0xFFFFAB76};
        for (int i = 0; i < 10; i++) {
            float y0 = top + i * rh;
            boolean mine = i < list.size() && list.get(i).runId == highlightRun;
            p.setShader(null);
            p.setStyle(Paint.Style.FILL);
            p.setColor(mine ? 0x55FFD23F : (i % 2 == 0 ? 0x22FFFFFF : 0x11FFFFFF));
            tmp.set(left, y0 + 2 * dp, right, y0 + rh - 2 * dp);
            c.drawRoundRect(tmp, 12 * dp, 12 * dp, p);
            float base = y0 + rh / 2 + 7 * dp;
            text(c, String.valueOf(i + 1), left + 26 * dp, base, 20 * dp, i < 3 ? medal[i] : 0xFFFFFFFF, Paint.Align.CENTER);
            if (i < list.size()) {
                ScoreStore.Entry e = list.get(i);
                text(c, dateFmt.format(new Date(e.time)), left + 56 * dp, base - 1 * dp, 14 * dp, 0x99FFFFFF, Paint.Align.LEFT);
                text(c, String.valueOf(e.score), right - 16 * dp, base, 22 * dp, 0xFFFFFFFF, Paint.Align.RIGHT);
            } else {
                text(c, "—", right - 16 * dp, base, 22 * dp, 0x55FFFFFF, Paint.Align.RIGHT);
            }
        }
        for (Btn b : scoreBtns) drawBtn(c, b);
    }

    // =====================================================================
    //  Ввод
    // =====================================================================
    private void computeAim() {
        float dx = aimX - shooterX, dy = aimY - shooterY;
        aimValid = dy < -d * 0.8f;   // отпустить палец ниже шара = отмена выстрела
        if (!aimValid) {
            aimN = 0;
            ghostOn = false;
            return;
        }
        float ang = (float) Math.atan2(-dy, dx);
        float mn = (float) Math.toRadians(11);
        if (ang < mn) ang = mn;
        if (ang > (float) Math.PI - mn) ang = (float) Math.PI - mn;
        aimAng = ang;
        float vx = (float) Math.cos(ang), vy = -(float) Math.sin(ang);
        float x = shooterX, y = shooterY, step = d * 0.3f;
        float minX = fieldLeft + r, maxX = fieldLeft + fieldW - r;
        aimN = 0;
        for (int i = 0; i < 700; i++) {
            x += vx * step;
            y += vy * step;
            if (x < minX) {
                x = minX + (minX - x);
                vx = -vx;
            } else if (x > maxX) {
                x = maxX - (x - maxX);
                vx = -vx;
            }
            if (y <= gridTop + r || hitBall(x, y) >= 0) break;
            if (i >= 3 && i % 3 == 0 && aimN < aimPts.length / 2) {
                aimPts[2 * aimN] = x;
                aimPts[2 * aimN + 1] = y;
                aimN++;
            }
        }
        int[] cell = snapCell(x, y);
        ghostX = cellX(cell[0], cell[1]);
        ghostY = cellY(cell[0]);
        ghostOn = true;
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        float x = e.getX(), y = e.getY();
        int act = e.getActionMasked();
        if (state == S_PLAY) {
            float nx = shooterX - 2.5f * d, ny = shooterY + 0.1f * d;
            switch (act) {
                case MotionEvent.ACTION_DOWN:
                    if (Math.hypot(x - pauseCx, y - pauseCy) < pauseR + 12 * dp) {
                        pauseDown = true;
                    } else if (phase == P_AIM && Math.hypot(x - nx, y - ny) < 1.2f * d) {
                        swapDown = true;
                    } else {
                        aiming = true;
                        aimX = x;
                        aimY = y;
                        computeAim();
                    }
                    break;
                case MotionEvent.ACTION_MOVE:
                    if (aiming) {
                        aimX = x;
                        aimY = y;
                        computeAim();
                    }
                    break;
                case MotionEvent.ACTION_UP:
                    if (pauseDown && Math.hypot(x - pauseCx, y - pauseCy) < pauseR + 12 * dp) {
                        handleBack();
                    } else if (swapDown && Math.hypot(x - nx, y - ny) < 1.2f * d && phase == P_AIM && curType >= 0) {
                        int t = curType;
                        curType = nextType;
                        nextType = t;
                        reloadT = 0.5f;
                    } else if (aiming && phase == P_AIM) {
                        aimX = x;
                        aimY = y;
                        computeAim();
                        if (aimValid && curType >= 0 && reloadT > 0.5f) fire();
                    }
                    aiming = false;
                    pauseDown = false;
                    swapDown = false;
                    break;
                case MotionEvent.ACTION_CANCEL:
                    aiming = false;
                    pauseDown = false;
                    swapDown = false;
                    break;
                default:
                    break;
            }
            return true;
        }

        ArrayList<Btn> list = null;
        if (state == S_MENU) list = menuBtns;
        else if (state == S_SCORES) list = scoreBtns;
        else if (state == S_PAUSE) list = pauseBtns;
        else if (state == S_OVER && overT > 0.8f) list = overBtns;
        if (list == null) return true;

        switch (act) {
            case MotionEvent.ACTION_DOWN:
            case MotionEvent.ACTION_MOVE:
                for (Btn b : list) b.down = b.r.contains(x, y);
                break;
            case MotionEvent.ACTION_UP:
                for (Btn b : list) {
                    if (b.down && b.r.contains(x, y)) {
                        for (Btn o : list) o.down = false;
                        onButton(b.id);
                        break;
                    }
                }
                for (Btn b : list) b.down = false;
                break;
            case MotionEvent.ACTION_CANCEL:
                for (Btn b : list) b.down = false;
                break;
            default:
                break;
        }
        return true;
    }

    private void onButton(int id) {
        switch (id) {
            case B_PLAY:
            case B_AGAIN:
                newGame();
                break;
            case B_SCORES:
                highlightRun = -1;
                state = S_SCORES;
                break;
            case B_EXIT:
                if (getContext() instanceof Activity) ((Activity) getContext()).finish();
                break;
            case B_MENU:
            case B_BACK:
                store.commit(runId, score);
                bestScore = Math.max(bestScore, store.best());
                state = S_MENU;
                break;
            case B_RESUME:
                resumeGame();
                break;
            default:
                break;
        }
    }
}
