# Ball Burst (офлайн, Android 8+/targetSdk 36)

## Сборка APK
1. Android Studio (Meerkat 2024.3.2 или новее): File → Open → папка проекта, дождаться Sync,
   затем Build → Build APK(s). Файл: app/build/outputs/apk/debug/app-debug.apk
2. Командная строка (при установленных JDK 17, Android SDK 36 и Gradle 8.11+): gradle assembleDebug
3. GitHub: загрузить проект в репозиторий, вкладка Actions → Build APK → Run workflow,
   готовый APK скачать из Artifacts.

## Установка
Скопировать app-debug.apk на телефон и открыть (разрешить установку из этого источника)
или: adb install app-debug.apk

## Настройки игры (GameView.java, начало файла)
COLS, START_ROWS, FIRE_RADIUS, BOOST_CHANCE, SINCE_BOOST_MIN, SHOT_SPEED_H
